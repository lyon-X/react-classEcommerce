export const Users = [
  { id: 1, name: "Osas", email: "Osas@mail.com" },
  { id: 2, name: "sas", email: "sas@mail.com" },
  { id: 3, name: "vinx", email: "vinx@mail.com" },
  { id: 4, name: "dessy", email: "dessy@mail.com" },
];

export const ProductDetails = [
  {
    id: 1,
    productName: "Samsung",
    productPrice: 200.0,
    img: "images/logo_1.png",
  },
  {
    id: 2,
    productName: "MacBook",
    productPrice: 320.0,
    img: "images/smart8hd.jpg",
  },
  {
    id: 3,
    productName: "Infinix",
    productPrice: 120.0,
    img: "images/images-removebg-preview (1).png",
  },
  {
    id: 4,
    productName: "Lenovo",
    productPrice: 220.0,
    img: "images/logo_1.png",
  },
  {
    id: 5,
    productName: "Tecno",
    productPrice: 225.0,
    img: "images/images-removebg-preview (1).png",
  },
];
